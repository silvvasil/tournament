#include <iostream>
#include <algorithm>
#include <math.h>
#include <set>
#include <vector>
#include <string>
#include <map>
#include <deque>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <random>
#include <string_view>

using namespace std;

#pragma GCC optimize("Ofast")

const int N = 41;
const int M = 45;

string field[N];

bool scan() {
    for (int i = 0; i < N; ++i) {
        if (!(cin >> field[i])) {
            return false;
        }
    }
    return true;
}

int SU;

void dfs(int i, int j, vector<vector<int>>& a, int c1, int c2) {
    SU++;
    a[i][j] = c2;
    if (i != 0 && a[i - 1][j] == c1) dfs(i - 1, j, a, c1, c2);
    if (i != N - 1 && a[i + 1][j] == c1) dfs(i + 1, j, a, c1, c2);
    if (j != 0 && a[i][j - 1] == c1) dfs(i, j - 1, a, c1, c2);
    if (j != M - 1 && a[i][j + 1] == c1) dfs(i, j + 1, a, c1, c2);
}

void dfs2(int i, int j, vector<vector<int>>& a, int t, vector<int>& _ma, vector<int>& _mas) {
    _ma[i * 100 + j] = t;
    _mas[t]++;
    if (i != 0 && a[i][j] == a[i - 1][j] && !_ma[i * 100 + j - 100])dfs2(i - 1, j, a, t, _ma, _mas);
    if (j != 0 && a[i][j] == a[i][j - 1] && !_ma[i * 100 + j - 1])dfs2(i, j - 1, a, t, _ma, _mas);
    if (i != N - 1 && a[i][j] == a[i + 1][j] && !_ma[i * 100 + j + 100])dfs2(i + 1, j, a, t, _ma, _mas);
    if (j != M - 1 && a[i][j] == a[i][j + 1] && !_ma[i * 100 + j + 1])dfs2(i, j + 1, a, t, _ma, _mas);
}

void recolor() {
    int c1 = field[0][0] - '0';
    int c2 = field[N - 1][M - 1] - '0';
    vector<vector<int>> a(N, vector<int>(M));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            a[i][j] = field[i][j] - '0';
        }
    }
    vector<int> _ma(100 * N + M);
    vector<int> _mas(N * M + 100);
    int T = 1;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            if (!_ma[i * 100 + j]) {
                dfs2(i, j, a, T, _ma, _mas);
                T++;
            }
        }
    }
    vector<vector<set<int>>> gr(T, vector<set<int>>(6));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            if (i != 0 && _ma[i * 100 + j - 100] != _ma[i * 100 + j]) gr[_ma[i * 100 + j]][a[i - 1][j] - 1].insert(_ma[i * 100 + j - 100]);
            if (j != 0 && _ma[i * 100 + j - 1] != _ma[i * 100 + j]) gr[_ma[i * 100 + j]][a[i][j - 1] - 1].insert(_ma[i * 100 + j - 1]);
            if (i != N - 1 && _ma[i * 100 + j + 100] != _ma[i * 100 + j]) gr[_ma[i * 100 + j]][a[i + 1][j] - 1].insert(_ma[i * 100 + j + 100]);
            if (j != M - 1 && _ma[i * 100 + j + 1] != _ma[i * 100 + j]) gr[_ma[i * 100 + j]][a[i][j + 1] - 1].insert(_ma[i * 100 + j + 1]);
        }
    }

    int d = _mas[0] - _mas[_ma[N * 100 + M - 100 - 1]];
    double mas = -1e9;
    int an1 = -1;
    for (int A = 1; A < 7; A++) {
        if (A == c1 || A == c2) continue;
        double S4 = 0;
        vector < double> cnt4;
        for (int B = 1; B < 7; B++) {
            if (B == A || B == c2) continue;
            double S3 = -1e9;
            for (int C = 1; C < 7; C++) {
                if (C == A || C == B) continue;
                double S2 = 0;
                vector < double> cnt2;
                for (int D = 1; D < 7; D++) {
                    if (D == C || D == B) continue;
                    double S1 = -1e9;
                    for (int E = 1; E < 7; E++) {
                        if (E == C || E == D) continue;

                        set<int> se1, se2;
                        vector<int> us(T);
                        se1.insert(_ma[0]);
                        se2.insert(_ma[100 * N + M - 100 - 1]);
                        vector<int> ad;
                        for (int v : se1) {
                            for (int u : gr[v][A - 1]) {
                                if (us[u]) continue;
                                us[u] = 1;
                                ad.push_back(u);
                            }
                        }
                        for (int x : ad) se1.insert(x);
                        ad.clear();
                        for (int v : se2) {
                            for (int u : gr[v][B - 1]) {
                                if (us[u]) continue;
                                us[u] = 1;
                                ad.push_back(u);
                            }
                        }
                        for (int x : ad) se2.insert(x);
                        ad.clear();
                        for (int v : se1) {
                            for (int u : gr[v][C - 1]) {
                                if (us[u]) continue;
                                us[u] = 1;
                                ad.push_back(u);
                            }
                        }
                        for (int x : ad) se1.insert(x);
                        ad.clear();
                        for (int v : se2) {
                            for (int u : gr[v][D - 1]) {
                                if (us[u]) continue;
                                us[u] = 1;
                                ad.push_back(u);
                            }
                        }
                        for (int x : ad) se2.insert(x);
                        ad.clear();
                        for (int v : se1) {
                            for (int u : gr[v][E - 1]) {
                                if (us[u]) continue;
                                us[u] = 1;
                                ad.push_back(u);
                            }
                        }
                        for (int x : ad) se1.insert(x);
                        ad.clear();
                        int d1 = int(se1.size());
                        int d2 = int(se2.size());
                        double S0 = d1 - d2;
                        S1 = max(S1, S0);
                    }
                    cnt2.push_back(S1);
                }
                sort(cnt2.begin(), cnt2.end());
                for (int i = 0; i<int(cnt2.size()); i++) {
                    if (i<int(cnt2.size()) / 2) {
                        S2 += cnt2[i] * 3 / (double(cnt2.size()) / 2 + double(cnt2.size()) * 3 / 2);
                    }
                    else {
                        S2 += cnt2[i] / (double(cnt2.size()) / 2 + double(cnt2.size()) * 3 / 2);
                    }
                }
                S3 = max(S2, S3);
            }
            cnt4.push_back(S3);
        }
        sort(cnt4.begin(), cnt4.end());
        for (int i = 0; i<int(cnt4.size()); i++) {
            if (i<int(cnt4.size()) / 4) {
                S4 += cnt4[i] * 3 / (double(cnt4.size())*3 / 4 + double(cnt4.size()) * 3 / 4);
            }
            else {
                S4 += cnt4[i] / (double(cnt4.size()) * 3 / 4 + double(cnt4.size()) * 3 / 4);
            }
        }
        if (mas < S4) {
            mas = S4;
            an1 = A;
        }
    }
    cout << an1 << endl;
}

int main() {
    scan();
    recolor();
}





