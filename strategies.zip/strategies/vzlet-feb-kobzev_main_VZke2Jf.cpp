#include <iostream>
#include <string>
#include <random>
#include <ctime>
#include <vector>
#include <queue>
using namespace std;

const int N = 41;
const int M = 45;

string a[N];

bool scan(){
	for (int i = 0; i < N; ++i) {
		if (!(cin >> a[i])) {
		return false;
		}
	}
	return true;
}

mt19937 rnd(time(0));

int used[N][M];
pair<int, int> d[4] = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
int clr[N][M];
vector<int> sz;

int dist = 0;
pair<int, int> best = {-1, -1};

void dfs(int x, int y) {
    used[x][y] = 1;
    if (a[x][y] != a[0][0]) {
        if (dist < x + y) {
            dist = x + y;
            best = {x, y};
        } else if (dist == x + y && sz[clr[x][y]] > sz[clr[best.first][best.second]]) {
            best = {x, y};
        }
        return;
    }
    shuffle(d, d + 4, rnd);
    for (auto& [dx, dy] : d) {
        int nx = x + dx;
        int ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= N || ny >= M || used[nx][ny] || a[nx][ny] == a[N - 1][M - 1]) continue;
        dfs(nx, ny);
    }
}

void find() {
    pair<int, int> d[4] = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
    vector<vector<int>> used1(N, vector<int>(M));
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            if (used[i][j]) continue;
            queue<pair<int, int>> q;
            q.push({i, j});
            sz.push_back(1);
            used1[i][j] = 1;
            while (q.size()) {
                auto [x, y] = q.front();
                q.pop();
                clr[x][y] = sz.size() - 1;
                for (auto& [dx, dy] : d) {
                    int nx = x + dx;
                    int ny = y + dy;
                    if (nx < 0 || ny < 0 || nx >= N || ny >= M || a[nx][ny] != a[x][y] || used1[nx][ny]) continue;
                    sz.back()++;
                    q.push({nx, ny});
                    used1[nx][ny] = 1;
                }
            }
        }
    }
    dfs(0, 0);
    int c;
    if (best.first == -1) {
        for (c = 1; c <= 6; ++c) {
            if (c == a[0][0] - '0' || c == a[N - 1][M - 1] - '0') continue;
            break;
        }
    } else {
        c = a[best.first][best.second] - '0';
    }
    cout << c << endl;
}

int main(){
	scan();
	find();
}