------------ BEGIN log session -------------
[21:28:08]	INI: HotKey 'Joystick2+Key0' is unknown
[21:28:08]	INI: HotKey 'Joystick+Key0' is unknown
[21:31:37]	Loading mission ...
[21:31:38]	Load landscape...
[21:31:54]	Load bridges
[21:31:54]	LongBridge: wrong width. (BRIDGE_RAIL_SMALL)
[21:31:56]	Load static objects...
[21:32:02]	Spawn.get( Vehicle.custom_chief56 ) NOT FOUND
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:32:03]	Server: CODEX будет летать за Красные ВВС.
[21:32:12]	Mission loaded. time = 35,298
[21:32:14]	Battle starting...[21:32:14]	Server: Битва начинается!
[21:32:14]	ok
[21:35:37]	
[21:35:37]	=================================================
[21:35:37]	System.NullReferenceException: Ссылка на объект не указывает на экземпляр объекта.
[21:35:37]	   в 4Foa4fNR32pGZfvisCUZHC4xrA.kZ9zmEEicOLhJXGCBipNeqPNS4y(Int32 )
[21:35:37]	   в WC2ZWEhyWCmdcRcagw2ktCgjRa4.yfo2kRPvEqNtjUK2EKgSedIXUUA()
[21:35:37]	   в tVRclB3yzKzeyXUhHmDWsbh0NZp.nppcCqgkNT0Z3Io237ppV4W5F5g()
[21:35:37]	=================================================
[21:38:05]	Server: Битва закончена.
[21:38:09]	
[21:38:09]	=================================================
[21:38:09]	SectFile load failed:
[21:38:09]	System.IO.IOException: File not found: C:\Users\UsePC\Documents\1C SoftClub\il-2 sturmovik cliffs of dover/mission/campaign/campaign_gb/state.ini
[21:38:09]	   в atHnD18fdiqtfgccwuzOfau9xmX..ctor(String )
[21:38:09]	   в uCZc22BGu6fJrg6g2jhDlMi90UV.iTx0ACYK8YZmB2tLef9c4CMMDWj(Stream , Boolean )
[21:38:09]	=================================================
[21:38:09]	
[21:38:09]	=================================================
[21:38:09]	SectFile load failed:
[21:38:09]	System.IO.IOException: File not found: C:\Users\UsePC\Documents\1C SoftClub\il-2 sturmovik cliffs of dover/mission/campaign/campaign_de/state.ini
[21:38:09]	   в atHnD18fdiqtfgccwuzOfau9xmX..ctor(String )
[21:38:09]	   в uCZc22BGu6fJrg6g2jhDlMi90UV.iTx0ACYK8YZmB2tLef9c4CMMDWj(Stream , Boolean )
[21:38:09]	=================================================
[21:39:00]	Loading mission ...
[21:39:02]	Load landscape...
[21:39:04]	Load bridges
[21:39:06]	Load static objects...
[21:39:10]	Spawn.get( Vehicle.custom_chief56 ) NOT FOUND
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Mission: ActorSpawn for 'Stationary.Airfield.90_cm_SearchLight_UK1' not found
[21:39:10]	Server: CODEX будет летать за Красные ВВС.
[21:39:14]	Mission loaded. time = 13,777
[21:39:15]	Battle starting...[21:39:15]	Server: Битва начинается!
[21:39:15]	ok
[21:40:43]	Server: Битва закончена.
[17.12.2021 21:40:48]	-------------- END log session -------------
