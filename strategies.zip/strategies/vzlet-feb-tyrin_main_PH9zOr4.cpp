#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan() {
  for (int i = 0; i < N; ++i) {
    if (!(cin >> field[i])) {
      return false;
    }
  }
  return true;
}

char used[N][M]{};

void recolor() {
  int color = field[0][0] - '0';
  int col_c[7]{};
  queue<pair<int, int>> q;
  q.emplace(0, 0);
  while (!q.empty()) {
    int a = q.front().first;
    int b = q.front().second;
    q.pop();
    if (field[a][b] - '0' != color) {
      col_c[field[a][b] - '0']++;
      continue;
    }
    if (a + 1 < N && !used[a + 1][b]) {
      q.emplace(a + 1, b);
      used[a + 1][b] = 1;
    }
    if (b + 1 < M && !used[a][b + 1]) {
      q.emplace(a, b + 1);
      used[a][b + 1] = 1;
    }
  }
  int ncolor = 0;
  for (int i = 0; i < 7; ++i) {
    if (col_c[i] > col_c[ncolor] && i != color && i != field[N - 1][M - 1] - '0') {
      ncolor = i;
    }
  }
  if (ncolor == 0) {
    ncolor = (color == 1 ? (field[N - 1][M - 1] - '0' == 2 ? 3 : 2) : (field[N - 1][M - 1] - '0' == 1 ? (color == 2 ? 3 : 2) : 1));
  }
  cout << ncolor << endl;
}

int main() {
  scan();
  recolor();
}