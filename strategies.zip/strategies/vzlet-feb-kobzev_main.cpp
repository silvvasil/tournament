#include <iostream>
#include <string>
#include <random>
#include <ctime>
#include <vector>

using namespace std;

const int N = 41;
const int M = 45;

string a[N];

bool scan(){
	for (int i = 0; i < N; ++i) {
		if (!(cin >> a[i])) {
		return false;
		}
	}
	return true;
}

int used[N][M];

mt19937 rnd(time(0));

void find() {
	vector<int> cnt(7);
	pair<int, int> d[4] = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
	for (int x = 0; x < N; ++x) {
		for (int y = 0; y < M; ++y) {
			if (a[x][y] != a[0][0] || used[x][y]) continue;
			for (auto& [dx, dy] : d) {
				int nx = x + dx;
				int ny = y + dy;
				if (nx >= N || nx < 0 || ny >= M || ny < 0 || used[nx][ny]) continue;
				++cnt[a[nx][ny]-'0'];
				used[nx][ny] = 1;
			}
		}
	}
	int w = -1;
	for (int c = 1; c <= 6; ++c) {
		if (c == a[0][0] - '0' || c == a[N - 1][M - 1] - '0') continue;
		if (w == -1 || cnt[w] < cnt[c]) w = c;
	}
	cout << w << endl;
}

int main(){
	scan();
	find();
}