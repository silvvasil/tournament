#include <iostream>
#include <vector>
#include <set>
#include <map>
#include <string>
#include <algorithm>
#include <queue>

using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan(){
    for (int i = 0; i < N; ++i) {
        if (!(cin >> field[i])) {
            return false;
        }
    }
    return true;
}

vector<pair<int, int>> dirs = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };

float weights[6] {
    1, 0.5, 0, 0, 0, 0
};

void recolor() {
    int colLocal = field[0][0] - '0';
    int colRemote = field[N - 1][M - 1] - '0';
    vector<double> cnts(6);
    vector<vector<bool>> captured(N, vector<bool>(M));
    captured[0][0] = true;

    queue<pair<int, int>> q;
    q.push({0, 0});
    while(q.size()) {
        auto [y, x] = q.front();
        q.pop();
        for(auto [dx, dy] : dirs) {
            int tx = x + dx, ty = y + dy;
            if(tx < 0 || ty < 0 || tx >= M || ty >= N) continue;
            if(captured[ty][tx]) continue;
            captured[ty][tx] = true;
            q.push({ty, tx});
        }
    }

    vector<vector<int>> dists(N, vector<int>(M, -1));
    for(int i = 0; i < N; i++) {
        for(int j = 0; j < M; j++) {
            if(!captured[i][j]) continue;
            dists[i][j] = 0;
            q.push({i, j});
        }
    }
    while(q.size()) {
        auto [y, x] = q.front();
        q.pop();
        for(auto [dx, dy] : dirs) {
            int tx = x + dx, ty = y + dy;
            if(tx < 0 || ty < 0 || tx >= M || ty >= N) continue;
            if(dists[ty][tx] != -1) continue;
            dists[ty][tx] = dists[y][x] + 1;
            q.push({ty, tx});
        }
    }

    for(int i = 0; i < N; i++) {
        for(int j = 0; j < M; j++) {
            if(dists[i][j] == 0 || dists[i][j] >= 7) continue;
            // double tt = 1;
            // for(int t = 0; t < 2; t++) tt *= (3.5 - dists[i][j]);
            // cnts[field[i][j] - '1'] += tt;
            long long sqd = i * i + j * j;
            cnts[field[i][j] - '1'] += weights[dists[i][j] - 1] * sqd * sqd * sqd;
            // cnts[field[i][j] - '1'] += 2 - dists[i][j];
        }
    }
    cnts[colRemote - 1] = -1000;
    int maxCol = max_element(cnts.begin(), cnts.end()) - cnts.begin();
    while(maxCol == colLocal - 1 || maxCol == colRemote - 1) maxCol = rand() % 6;
    cout << maxCol + 1;
}

int get_hash() {
    int sumh = 0;
    for (int i = 0; i < N; ++i) {
        sumh += hash<string_view>{}(field[i]);
    }
    return sumh;
}


int main(){
    scan();
    srand(get_hash());
    recolor();
}
