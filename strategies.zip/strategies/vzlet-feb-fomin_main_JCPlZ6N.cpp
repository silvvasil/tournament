int y = 1;

const int N = 41;
const int M = 45;

#include<iostream>
#include<vector>

using namespace std;


vector<vector<int>> arr;
class Algo {
public:
    virtual int calc(vector<vector<int>> aa) = 0;
};


class AL1 : public Algo {
    int dfs(vector<vector<int>> &arr1, pair<int, int> s, int cc, int nc) {
        if (arr1[s.first][s.second] != cc)return 0;
        arr1[s.first][s.second] = nc;
        int ans = 0;
        ans += dfs(arr1, {s.first, s.second + 1}, cc, nc);
        ans += dfs(arr1, {s.first + 1, s.second}, cc, nc);
        return ans + 1;
    }

public:
    int calc(vector<vector<int>> aa) override {
        auto a1 = aa;
        auto a2 = aa;
        auto a3 = aa;
        auto a4 = aa;
        auto a5 = aa;
        auto a6 = aa;
        pair<int, int> ans = {0, 1};
        if (1 != aa[0][0] && 1 != aa.back().back()) {
            int l=dfs(a1, {0, 0}, a1[0][0], 1);
            ans=max(ans,{l,1});
        }
        if (2 != aa[0][0] && 2 != aa.back().back()) {
            int l=dfs(a2, {0, 0}, a2[0][0], 2);
            ans=max(ans,{l,2});
        }
        if (3 != aa[0][0] && 3 != aa.back().back()) {
            int l=dfs(a3, {0, 0}, a3[0][0], 3);
            ans=max(ans,{l,3});
        }
        if (4 != aa[0][0] && 4 != aa.back().back()) {
            int l=dfs(a4, {0, 0}, a4[0][0], 4);
            ans=max(ans,{l,4});
        }
        if (5 != aa[0][0] && 5 != aa.back().back()) {
            int l=dfs(a5, {0, 0}, a5[0][0], 5);
            ans=max(ans,{l,5});
        }
        if (6 != aa[0][0] && 6 != aa.back().back()) {
            int l=dfs(a6, {0, 0}, a6[0][0], 6);
            ans=max(ans,{l,6});
        }
        return ans.second;
    }
};


bool scan() {
    for(int i=0;i<N;i++) {
        for (int j = 0; j < M; j++) {
            char t;
            cin >> t;
            arr[0][i] = t - '0';
        }
    }
    return true;
}
void recolor() {
    cout<<AL1().calc(arr);
}

int main() {
    scan();
    recolor();
}
