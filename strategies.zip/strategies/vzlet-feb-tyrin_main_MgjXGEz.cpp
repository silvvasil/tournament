#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan() {
  for (int i = 0; i < N; ++i) {
    if (!(cin >> field[i])) {
      return false;
    }
  }
  return true;
}

char used[N][M]{};

void DUMB() {
  int color = field[0][0] - '0';
  int col_c[7]{};
  queue<pair<int, int>> q;
  q.emplace(0, 0);
  while (!q.empty()) {
    int a = q.front().first;
    int b = q.front().second;
    q.pop();
    if (field[a][b] - '0' != color) {
      col_c[field[a][b] - '0']++;
      continue;
    }
    if (a + 1 < N && !used[a + 1][b]) {
      q.emplace(a + 1, b);
      used[a + 1][b] = 1;
    }
    if (b + 1 < M && !used[a][b + 1]) {
      q.emplace(a, b + 1);
      used[a][b + 1] = 1;
    }
  }
  int ncolor = 0;
  for (int i = 0; i < 7; ++i) {
    if (col_c[i] > col_c[ncolor] && i != color && i != field[N - 1][M - 1] - '0') {
      ncolor = i;
    }
  }
  if (ncolor == 0) {
    ncolor = (color == 1 ? (field[N - 1][M - 1] - '0' == 2 ? 3 : 2) : (field[N - 1][M - 1] - '0' == 1 ? (color == 2 ? 3 : 2) : 1));
  }
  cout << ncolor << endl;
}

int go(queue<pair<int, int>>& q1, queue<pair<int, int>>& q2, deque<int>& next_col, int ind, int color) {
  if (q1.empty()) return 0;
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < M; ++j) {
      used[i][j] = 0;
    }
  }
  queue<pair<int, int>> next1, next2;
  int c = 0;
  while (!q1.empty()) {
    int a = q1.front().first;
    int b = q1.front().second;
    q1.pop();
    if (field[a][b] - '0' != color) {
      if (field[a][b] - '0' == next_col[ind]) {
        next1.emplace(a, b);
      }
      continue;
    }
    c++;
    if (a + 1 < N && !used[a + 1][b]) {
      q1.emplace(a + 1, b);
      used[a + 1][b] = 1;
    }
    if (b + 1 < M && !used[a][b + 1]) {
      q1.emplace(a, b + 1);
      used[a][b + 1] = 1;
    }
  }
  int c2 = 0;
  while (!q2.empty()) {
    int a = q2.front().first;
    int b = q2.front().second;
    q2.pop();
    if (field[a][b] - '0' != color) {
      if (field[a][b] - '0' == next_col[ind]) {
        next2.emplace(a, b);
      }
      continue;
    }
    c2++;
    if (a - 1 > -1 && !used[a - 1][b]) {
      q2.emplace(a - 1, b);
      used[a - 1][b] = 1;
    }
    if (b - 1 > -1 && !used[a][b - 1]) {
      q2.emplace(a, b + 1);
      used[a][b - 1] = 1;
    }
  }
  return (!!ind) * (c - c2) + go(next1, next2, next_col, ind + 1, next_col[ind]);
}

int go_greed(deque<int> next_col) {
  next_col.push_back(-1);
  int color = field[0][0] - '0';
  queue<pair<int, int>> q1, q2;
  q1.emplace(0, 0);
  q2.emplace(N - 1, M - 1);
  return go(q1, q2, next_col, 0, color);
}

pair<int, int> greeds(int I, int MAX, deque<int>& d) {
  if (I == MAX) {
    return { go_greed(d), 0 };
  }
  pair<int, int> best = { -1, -1 };
  for (int i = 1; i <= 6; ++i) {
    if (field[0][0] - '0' == i) continue;
    if (field[N - 1][M - 1] - '0' == i) continue;
    if (!d.empty() && i == d.back()) continue;
    d.push_back(i);
    auto p = greeds(I + 1, MAX, d);
    d.pop_back();
    if (best.first < p.first) {
      best = { p.first, i };
    }
  }
  return best;
}

void recolor() {
  int K = 3;
  deque<int> d;
  auto p = greeds(0, K, d);
  if (p.second == 0) {
    cout << (field[0][0] - '0' == 1 ? (field[N - 1][M - 1] - '0' == 2 ? 3 : 2) : (field[N - 1][M - 1] - '0' == 1 ? (field[0][0] - '0' == 2 ? 3 : 2) : 1)) << endl;
  }
  else {
    cout << p.second << endl;
  }
}

int main() {
  scan();
  recolor();
}