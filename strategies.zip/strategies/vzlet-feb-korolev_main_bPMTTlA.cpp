﻿#include <iostream>
#include <algorithm>
#include <math.h>
#include <set>
#include <vector>
#include <string>
#include <map>
#include <deque>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <random>
#include <string_view>


using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan() {
    for (int i = 0; i < N; ++i) {
        if (!(cin >> field[i])) {
            return false;
        }
    }
    return true;
}

int rnd() {
    int color = field[0][0] - '0';
    for (int it = rand() % 6; true; it = rand() % 6) {
        int ncolor = (color + it);
        if (ncolor > 6) {
            ncolor -= 6;
        }
        if (ncolor == field[0][0] - '0' || ncolor == field[N - 1][M - 1] - '0') {
            continue;
        }
        return ncolor;
        break;
    }
}

void recolor() {
    int c1 = field[0][0] - '0';
    int c2 = field[N - 1][M - 1] - '0';
    vector<vector<int>> a(N, vector<int>(M));
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            a[i][j] = field[i][j] - '0';
        }
    }
    int mas = 0;
    int an1 = -1, an2 = -1;
    for (int A = 1; A < 7; A++) {
        if (A == c1 || A == c2) continue;
        for (int B = 1; B < 7; B++) {
            if (B == A) continue;
            for (int C = 1; C < 7; C++) {
                if (C == B) continue;
                vector<vector<int>> b = a;
                for (int i = 0; i < N; i++) {
                    if (b[i][0] != c1) break;
                    for (int j = 0; j < M; j++) {
                        if (b[i][j] != c1) break;
                        b[i][j] = A;
                    }
                }
                for (int i = 0; i < N; i++) {
                    if (b[i][0] != A) break;
                    for (int j = 0; j < M; j++) {
                        if (b[i][j] != A) break;
                        b[i][j] = B;
                    }
                }
                for (int i = 0; i < N; i++) {
                    if (b[i][0] != B) break;
                    for (int j = 0; j < M; j++) {
                        if (b[i][j] != B) break;
                        b[i][j] = C;
                    }
                }
                int s = 0;
                for (int i = 0; i < N; i++) {
                    if (b[i][0] != b[0][0]) break;
                    for (int j = 0; j < M; j++) {
                        if (b[i][j] != b[0][0]) break;
                        s++;
                    }
                }
                if (s >= mas) {
                    mas = s;
                    an1 = A;
                    an2 = B;
                }
            }
        }
    }
    cout << an1 << endl;
}

void recolor2() {
    int color = field[0][0] - '0';
    for (int it = 0; it < 6; ++it) {
        int ncolor = (color + it);
        if (ncolor > 6) {
            ncolor -= 6;
        }
        if (ncolor == field[0][0] - '0' || ncolor == field[N - 1][M - 1] - '0') {
            continue;
        }
        cout << ncolor << endl;
        break;
    }
}

int main() {
    scan();
    recolor();
}


