/* 
Code By maksonchik20
*/

#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <algorithm>
#include <string>
#include <deque>
#include <functional>
#include <set>
#include <map>
#include <random>
#include <memory>
#include <cassert>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <bitset>
#include <time.h>
#include <stack>
#include <queue>
#include <complex>
#include <chrono>


using namespace std;
using ll = long long;
using ld = long double;

const ll MOD = (ll) 998244353;
const ld EPS = 0.00000000001;
const ll INF = (ll) 1e18;
const ld PI = 3.141592653589793238462643383279502884;

ll binpow(ll a, ll b) {
    if (b == 0) {
        return 1;
    }
    if (b == 1) {
        return a % MOD;
    }
    if (b % 2 == 0) {
        ll res = binpow(a, b / 2);
        // cout << a << " " << b << " " << res << endl;
        return (res * res) % MOD;
    } else {
        return (a * binpow(a, b - 1)) % MOD;
    }
}

void solve() {
    int n;
    cin >> n;
    vector<int> a(n);
    int maxi = 0;
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
        maxi = max(maxi, a[i]);
    }
    int cnt = 0, cnt2 = 0;
    for (int i = 0; i < n; ++i) {
        cnt += (a[i] == maxi - 1);
        cnt2 += (a[i] == maxi);
    }
    ll fact = 1;
    for (int i = 1; i <= n; ++i) {
        fact *= i;
        fact %= MOD;
    }
    if (cnt2 > 1) {
        cout << fact << "\n";
    } else {
        cout << (fact - (fact * binpow(cnt + 1, MOD - 2)) % MOD + MOD) % MOD << "\n";
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int t;
    // t = 1;
    cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}