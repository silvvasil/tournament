﻿#include <iostream>
#include <algorithm>
#include <math.h>
#include <set>
#include <vector>
#include <string>
#include <map>
#include <deque>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <random>
#include <string_view>


using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan() {
    for (int i = 0; i < N; ++i) {
        if (!(cin >> field[i])) {
            return false;
        }
    }
    return true;
}

int rnd() {
    int color = field[0][0] - '0';
    for (int it = rand() % 6; true; it = rand() % 6) {
        int ncolor = (color + it);
        if (ncolor > 6) {
            ncolor -= 6;
        }
        if (ncolor == field[0][0] - '0' || ncolor == field[N - 1][M - 1] - '0') {
            continue;
        }
        return ncolor;
        break;
    }
}

void recolor() {
    int c1 = field[0][0] - '0';
    int c2= field[N-1][M-1] - '0';
    int c = -1;
    for (int i = 0; i < 20; i++) {
        if (field[0][i] - '0' != c1) {
            c = field[0][0] - '0';
            break;
        }
    }
    if (c != -1) {
        if (c == c2 || c==c1) {
            cout << rnd() << endl;
            return;
        }
        else {
            cout << c << endl;
            return;
        }
    }
    for (int i = 0; i < M; i++) {
        if (field[i][19] - '0' != c1) {
            c = field[i][19] - '0';
            break;
        }
    }
    if (c == c2 || c==c1) {
        cout << rnd() << endl;
        return;
    }
    else {
        cout << c << endl;
        return;
    }
}

void recolor2() {
    int color = field[0][0] - '0';
    for (int it = 0; it < 6; ++it) {
        int ncolor = (color + it);
        if (ncolor > 6) {
            ncolor -= 6;
        }
        if (ncolor == field[0][0] - '0' || ncolor == field[N - 1][M - 1] - '0') {
            continue;
        }
        cout << ncolor << endl;
        break;
    }
}

int main() {
    scan();
    recolor();
}

