#include <iostream>
#include <string>
#include <random>
#include <ctime>
#include <vector>
#include <queue>

using namespace std;

const int N = 41;
const int M = 45;

#define int int64_t

string a[N];

bool scan(){
	for (int i = 0; i < N; ++i) {
		if (!(cin >> a[i])) {
		return false;
		}
	}
	return true;
}

mt19937 rnd(time(0));

void find() {
	vector<int> cnt(7), suf(7);
	pair<int, int> d[4] = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
    int tot = 0;
    auto bfs = [&](int i, int j, char col, vector<int>& cnt) {
        vector<vector<int>> used(N, vector<int>(M));
        queue<pair<int, int>> q;
        q.push({i, j});
        while (q.size()) {
            auto [x, y] = q.front();
            q.pop();
            if (a[x][y] != a[0][0]) {
                ++tot;
                continue;
            }
            for (auto& [dx, dy] : d) {
                int nx = x + dx;
                int ny = y + dy;
                if (nx >= N || nx < 0 || ny >= M || ny < 0 || used[nx][ny]) continue;
                ++cnt[a[nx][ny]-'0'];
                used[nx][ny] = 1;
                q.push({nx, ny});
            }
        }
    };
	bfs(0, 0, a[0][0], cnt);
    bfs(N - 1, M - 1, a[N - 1][M - 1], suf);

    double coef = (double)tot / (rnd() % tot + 1);

	int w = -1;
	for (int c = 1; c <= 6; ++c) {
		if (c == a[0][0] - '0' || c == a[N - 1][M - 1] - '0') continue;
		if (w == -1 || suf[w] * coef + cnt[w] * (tot / coef) < suf[c] * coef + cnt[c] * (tot / coef)) w = c;
	}
	cout << w << endl;
}

signed main(){
	scan();
	find();
}