#include <iostream>
#include <vector>
#include <map>
#include <set>

using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan(){
  for (int i = 0; i < N; ++i) {
    if (!(cin >> field[i])) {
      return false;
    }
  }
  return true;
}

vector<vector<pair<int, int>>> groups;

void comps(int i, int j, int color, vector<vector<int>>& used, vector<pair<int, int>>& cur) {
    if (used[i][j]) return;
    if (field[i][j] - '1' != color) return;
    used[i][j] = 1;
    cur.push_back({i, j});
    if (i + 1 < N) comps(i + 1, j, color, used, cur);
    if (i - 1 >= 0) comps(i - 1, j, color, used, cur);
    if (j + 1 < M) comps(i, j + 1, color, used, cur);
    if (j - 1 >= 0) comps(i, j - 1, color, used, cur);
}

void dfs1(int v, int color, vector<int>& cc, vector<int>& used, vector<set<int>>& g) {
    
}

void dfs(int i, int j, int color, vector<int>& cc, vector<vector<int>>& used) {
    if (used[i][j]) return;
    used[i][j] = 1;
    if (field[i][j] - '1' != color) {
        cc[field[i][j] - '1']++;
        return;
    }
    if (i + 1 < N) dfs(i + 1, j, color, cc, used);
    if (i - 1 >= 0) dfs(i - 1, j, color, cc, used);
    if (j + 1 < M) dfs(i, j + 1, color, cc, used);
    if (j - 1 >= 0) dfs(i, j - 1, color, cc, used);
}

void recolor() {
  // int color;
  vector<vector<int>> used(N, vector<int> (M));
  map<pair<int, int>, int> inds;
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < M; ++j) {
        if (used[i][j]) continue;
        vector<pair<int, int>> cur;
        comps(i, j, field[i][j] - '1', used, cur);
        for (auto& e : cur) inds[e] = groups.size();
        groups.push_back(cur);
    }
  }
  vector<set<int>> g(groups.size());
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < M; ++j) {
        if (i + 1 < N) {
            g[inds[{i, j}]].insert({inds[{i + 1, j}]});
        }
        if (i - 1 >= 0) {
            g[inds[{i, j}]].insert({inds[{i - 1, j}]});
        }
        if (j + 1 < M) {
            g[inds[{i, j}]].insert({inds[{i, j + 1}]});
        }
        if (j - 1 >= 0) {
            g[inds[{i, j}]].insert({inds[{i, j - 1}]});
        }
    }
  }
  vector<int> cc(6);
  for (auto& e : g[0]) {
    cc[field[groups[e][0].first][groups[e][0].second] - '1'] += groups[e].size();
  }
  int mx = -1;
  for (int i = 0; i < 6; ++i) {
    if (i == field[0][0] - '1' || i == field[N - 1][M - 1] - '1') continue;
    if (mx == -1 || cc[mx] <= cc[i]) mx = i;
  }
  /*do {
    color = rand() % 6 + 1;
  } while (color == field[0][0] - '0' || color == field[N - 1][M - 1] - '0');*/
  cout << mx + 1 << endl;
}

/*int get_hash() {
  int sumh = 0;
  for (int i = 0; i < N; ++i) {
    sumh += hash<string>{}(field[i]);
  }
  return sumh;
}*/


int main(){
  scan();
  // srand(get_hash());
  recolor();
}