#include <iostream>
#include <vector>

using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan(){
  for (int i = 0; i < N; ++i) {
    if (!(cin >> field[i])) {
      return false;
    }
  }
  return true;
}

void dfs(int i, int j, int color, vector<int>& cc, vector<vector<int>>& used) {
    if (used[i][j]) return;
    used[i][j] = 1;
    if (field[i][j] - '1' != color) {
        cc[field[i][j] - '1']++;
        return;
    }
    if (i + 1 < N) dfs(i + 1, j, color, cc, used);
    if (i - 1 >= 0) dfs(i - 1, j, color, cc, used);
    if (j + 1 < M) dfs(i, j + 1, color, cc, used);
    if (j - 1 >= 0) dfs(i, j - 1, color, cc, used);
}

void recolor() {
  // int color;
  vector<int> cc(6);
  vector<vector<int>> used(N, vector<int> (M));
  dfs(0, 0, field[0][0] - '1', cc, used);
  int mx = -1;
  for (int i = 0; i < 6; ++i) {
    if (i == field[0][0] - '1' || i == field[N - 1][M - 1] - '1') continue;
    if (mx == -1 || cc[mx] < cc[i]) mx = i;
  }
  /*do {
    color = rand() % 6 + 1;
  } while (color == field[0][0] - '0' || color == field[N - 1][M - 1] - '0');*/
  cout << mx + 1 << endl;
}

/*int get_hash() {
  int sumh = 0;
  for (int i = 0; i < N; ++i) {
    sumh += hash<string>{}(field[i]);
  }
  return sumh;
}*/


int main(){
  scan();
  // srand(get_hash());
  recolor();
}