#include <iostream>
#include <queue>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

const int N = 41;
const int M = 45;

string field[N];

bool scan() {
  for (int i = 0; i < N; ++i) {
    if (!(cin >> field[i])) {
      return false;
    }
  }
  return true;
}

char used[N][M]{};

int go_greed(int next_col) {
  for (int i = 0; i < N; ++i) {
    for (int j = 0; j < M; ++j) {
      used[i][j] = 0;
    }
  }
  int color = field[0][0] - '0';
  queue<pair<int, int>> q;
  queue<pair<int, int>> next;
  q.emplace(0, 0);
  while (!q.empty()) {
    int a = q.front().first;
    int b = q.front().second;
    q.pop();
    if (field[a][b] - '0' != color) {
      if (field[a][b] - '0' == next_col) {
        next.emplace(a, b);
      }
      continue;
    }
    if (a + 1 < N && !used[a + 1][b]) {
      q.emplace(a + 1, b);
      used[a + 1][b] = 1;
    }
    if (b + 1 < M && !used[a][b + 1]) {
      q.emplace(a, b + 1);
      used[a][b + 1] = 1;
    }
  }
  int c = 0;
  while (!next.empty()) {
    int a = next.front().first;
    int b = next.front().second;
    next.pop();
    if (field[a][b] - '0' != next_col) {
      continue;
    }
    c++;
    if (a + 1 < N && !used[a + 1][b]) {
      next.emplace(a + 1, b);
      used[a + 1][b] = 1;
    }
    if (b + 1 < M && !used[a][b + 1]) {
      next.emplace(a, b + 1);
      used[a][b + 1] = 1;
    }
  }
  return c;
}

void recolor() {
  int best = 0;
  int ans = 0;
  for (int i = 1; i <= 6; ++i) {
    if (field[0][0] - '0' == i) continue;
    if (field[N - 1][M - 1] - '0' == i) continue;
    int z = go_greed(i);
    if (z > ans) {
      best = i;
      ans = z;
    }
  }
  if (best == 0) {
    cout << (field[0][0] - '0' == 1 ? (field[N - 1][M - 1] - '0' == 2 ? 3 : 2) : (field[N - 1][M - 1] - '0' == 1 ? (field[0][0] - '0' == 2 ? 3 : 2) : 1)) << endl;
  }
  else {
    cout << best << endl;
  }
}

int main() {
  scan();
  recolor();
}