#include <iostream>
#include <string>
#include <random>
#include <ctime>
#include <vector>
#include <queue>

using namespace std;

const int N = 41;
const int M = 45;

string a[N];

bool scan(){
	for (int i = 0; i < N; ++i) {
		if (!(cin >> a[i])) {
		return false;
		}
	}
	return true;
}

mt19937 rnd(time(0));

void find() {
    vector<vector<int>> clr(N, vector<int>(M));
    vector<int> sz;
    pair<int, int> d[4] = {{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
    vector<vector<int>> used(N, vector<int>(M));
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            if (used[i][j]) continue;
            queue<pair<int, int>> q;
            q.push({i, j});
            sz.push_back(1);
            used[i][j] = 1;
            while (q.size()) {
                auto [x, y] = q.front();
                q.pop();
                clr[x][y] = sz.size() - 1;
                for (auto& [dx, dy] : d) {
                    int nx = x + dx;
                    int ny = y + dy;
                    if (nx < 0 || ny < 0 || nx >= N || ny >= M || a[nx][ny] != a[x][y] || used[nx][ny]) continue;
                    sz.back()++;
                    q.push({nx, ny});
                    used[nx][ny] = 1;
                }
            }
        }
    }
	vector<int> cnt(7);
    auto bfs = [&](int i, int j, char col) {
        used = vector<vector<int>>(N, vector<int>(M));
        queue<pair<int, int>> q;
        q.push({i, j});
        while (q.size()) {
            auto [x, y] = q.front();
            q.pop();
            if (a[x][y] != col) {
                cnt[a[x][y]-'0'] += sz[clr[x][y]];
                continue;
            }
            for (auto& [dx, dy] : d) {
                int nx = x + dx;
                int ny = y + dy;
                if (nx >= N || nx < 0 || ny >= M || ny < 0 || used[nx][ny]) continue;
                used[nx][ny] = 1;
                q.push({nx, ny});
            }
        }
    };
    bfs(0, 0, a[0][0]);
    int w = -1;
    for (int c = 1; c < 7; ++c) {
        if (c == a[0][0] - '0' || c == a[N - 1][M - 1] - '0') continue;
        if (w == -1 || cnt[c] > cnt[w]) w = c;
    }
    cout << w << endl;
}

int main(){
	scan();
	find();
}